/* ==========================================================
   Glimpse – an infinite, zoomable wall of photos, 30-second
   videos and quotes. Plain JavaScript, no dependencies.

   Storage:
   - When served by server.js, posts go to the server and every
     visitor sees the same wall.
   - Opened any other way (e.g. as a local file), posts are kept
     in this browser with IndexedDB so you can still try it out.
   ========================================================== */
(() => {
  "use strict";

  /* ---------------------------------------------------------
     1. SETTINGS
     --------------------------------------------------------- */
  const MAX_VIDEO_SECONDS = 30;
  const MAX_VIDEO_MB = 60;
  const MAX_PHOTO_MB = 25;          // before resizing in the browser
  const PHOTO_MAX_PX = 1800;        // long edge of the stored photo
  const THUMB_MAX_PX = 520;         // long edge of the wall thumbnail
  const QUOTE_MAX = 280;
  const POLL_MS = 20000;            // how often to check the server for new posts

  const QUOTE_STYLES = [
    { id: "ink",   label: "Ink" },
    { id: "paper", label: "Paper" },
    { id: "sun",   label: "Sun" },
    { id: "bloom", label: "Bloom" },
  ];

  // Starter quotes for the browser-only preview (the server seeds its own copy).
  const SAMPLE_QUOTES = [
    ["We suffer more often in imagination than in reality.", "Seneca", "ink"],
    ["If you want to go fast, go alone. If you want to go far, go together.", "African proverb", "sun"],
    ["Do what you can, with what you have, where you are.", "Theodore Roosevelt", "paper"],
    ["Go confidently in the direction of your dreams.", "Henry David Thoreau", "bloom"],
    ["Nothing great was ever achieved without enthusiasm.", "Ralph Waldo Emerson", "sun"],
    ["Waste no more time arguing what a good person should be. Be one.", "Marcus Aurelius", "ink"],
    ["Little by little, one travels far.", "Proverb", "bloom"],
    ["Until the lion learns to write, tales of the hunt will glorify the hunter.", "African proverb", "paper"],
    ["The best way out is always through.", "Robert Frost", "ink"],
    ["Rest is not idleness.", "John Lubbock", "paper"],
    ["Simplicity is the ultimate sophistication.", "Attributed to Leonardo da Vinci", "sun"],
    ["Wherever you go, go with all your heart.", "Confucius", "bloom"],
  ];

  /* ---------------------------------------------------------
     2. HELPERS
     --------------------------------------------------------- */
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const mod = (n, m) => ((n % m) + m) % m;
  const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

  // Always escape user content before putting it into HTML.
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const ls = {
    get(k, fallback) { try { const v = localStorage.getItem(k); return v === null ? fallback : JSON.parse(v); } catch (_) { return fallback; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} },
  };

  function mulberry32(a) {
    return () => {
      a |= 0; a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const fmtDur = s => `${Math.floor(s / 60)}:${String(Math.round(s % 60)).padStart(2, "0")}`;
  const rtf = new Intl.RelativeTimeFormat("en", { numeric: "auto" });
  function timeAgo(ts) {
    const sec = (ts - Date.now()) / 1000;
    const steps = [[60, "second"], [3600, "minute"], [86400, "hour"], [604800, "day"], [2629800, "week"], [31557600, "month"], [Infinity, "year"]];
    const div = [1, 60, 3600, 86400, 604800, 2629800, 31557600];
    for (let i = 0; i < steps.length; i++) {
      if (Math.abs(sec) < steps[i][0]) return rtf.format(Math.round(sec / div[i]), steps[i][1]);
    }
  }

  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => t.classList.remove("show"), 2400);
  }

  /* ---------------------------------------------------------
     3. STORAGE
     Both stores expose: list(), create(data, onProgress),
     like(id, delta), remove(id, token)
     --------------------------------------------------------- */
  const ServerStore = {
    mode: "server",
    async list() {
      const r = await fetch("/api/posts", { headers: { Accept: "application/json" } });
      if (!r.ok) throw new Error("Couldn't load the wall.");
      return r.json();
    },
    create(data, onProgress) {
      return new Promise((resolve, reject) => {
        const fd = new FormData();
        for (const k of ["type", "author", "caption", "text", "quoteBy", "style", "width", "height", "duration"]) {
          if (data[k] !== undefined && data[k] !== null) fd.append(k, data[k]);
        }
        if (data.media) fd.append("media", data.media, data.mediaName || "media");
        if (data.thumb) fd.append("thumb", data.thumb, "thumb.jpg");
        const x = new XMLHttpRequest();
        x.open("POST", "/api/posts");
        x.upload.onprogress = e => { if (e.lengthComputable) onProgress?.(e.loaded / e.total); };
        x.onload = () => {
          let body = {};
          try { body = JSON.parse(x.responseText); } catch (_) {}
          if (x.status >= 200 && x.status < 300) resolve(body);
          else reject(new Error(body.error || `Upload failed (error ${x.status}). Try again.`));
        };
        x.onerror = () => reject(new Error("Upload failed. Check your connection and try again."));
        x.send(fd);
      });
    },
    async like(id, delta) {
      const r = await fetch(`/api/posts/${encodeURIComponent(id)}/like`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ delta }),
      });
      if (!r.ok) throw new Error("Couldn't save your like.");
      return (await r.json()).likes;
    },
    async remove(id, token) {
      const r = await fetch(`/api/posts/${encodeURIComponent(id)}`, { method: "DELETE", headers: { "X-Delete-Token": token } });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || "Couldn't delete this post.");
    },
  };

  const LocalStore = {
    mode: "local",
    db: null,
    mem: new Map(),      // fallback if IndexedDB is unavailable
    urls: new Map(),

    async open() {
      try {
        this.db = await new Promise((res, rej) => {
          const r = indexedDB.open("glimpse", 1);
          r.onupgradeneeded = () => r.result.createObjectStore("posts", { keyPath: "id" });
          r.onsuccess = () => res(r.result);
          r.onerror = () => rej(r.error);
        });
      } catch (_) { this.db = null; }
      if (!ls.get("glimpse:seeded", false) || (!this.db && !this.mem.size)) {
        const now = Date.now();
        for (const [i, [text, by, style]] of SAMPLE_QUOTES.entries()) {
          await this._put({ id: "sample-" + i, type: "quote", author: "Glimpse", text, quoteBy: by, style, likes: 3 + ((i * 7) % 20), createdAt: now - (i + 1) * 3.6e6 });
        }
        ls.set("glimpse:seeded", true);
      }
    },
    _req(r) { return new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); }); },
    _os(mode) { return this.db.transaction("posts", mode).objectStore("posts"); },
    async _put(p) { if (this.db) await this._req(this._os("readwrite").put(p)); else this.mem.set(p.id, p); },
    async _get(id) { return this.db ? this._req(this._os("readonly").get(id)) : this.mem.get(id); },
    async _all() { return this.db ? this._req(this._os("readonly").getAll()) : [...this.mem.values()]; },
    async _del(id) { if (this.db) await this._req(this._os("readwrite").delete(id)); else this.mem.delete(id); },
    _url(key, blob) { if (!this.urls.has(key)) this.urls.set(key, URL.createObjectURL(blob)); return this.urls.get(key); },
    _view(p) {
      const { mediaBlob, thumbBlob, ...v } = p;
      if (mediaBlob) v.url = this._url(p.id + ":m", mediaBlob);
      if (thumbBlob) v.thumb = this._url(p.id + ":t", thumbBlob);
      return v;
    },

    async list() {
      return (await this._all()).sort((a, b) => b.createdAt - a.createdAt).map(p => this._view(p));
    },
    async create(d, onProgress) {
      const p = {
        id: uid(), type: d.type, author: d.author || "Anonymous", caption: d.caption || "",
        text: d.text, quoteBy: d.quoteBy, style: d.style,
        width: d.width, height: d.height, duration: d.duration,
        likes: 0, createdAt: Date.now(), mediaBlob: d.media, thumbBlob: d.thumb,
      };
      await this._put(p);
      onProgress?.(1);
      return { post: this._view(p), deleteToken: "local" };
    },
    async like(id, delta) {
      const p = await this._get(id);
      if (!p) return 0;
      p.likes = Math.max(0, (p.likes || 0) + delta);
      await this._put(p);
      return p.likes;
    },
    async remove(id) {
      await this._del(id);
      for (const k of [id + ":m", id + ":t"]) {
        if (this.urls.has(k)) { URL.revokeObjectURL(this.urls.get(k)); this.urls.delete(k); }
      }
    },
  };

  async function pickStore() {
    if (location.protocol.startsWith("http")) {
      try {
        const r = await fetch("/api/posts", { headers: { Accept: "application/json" } });
        if (r.ok && (r.headers.get("content-type") || "").includes("json")) return ServerStore;
      } catch (_) {}
    }
    await LocalStore.open();
    return LocalStore;
  }

  /* ---------------------------------------------------------
     4. STATE
     --------------------------------------------------------- */
  let store = null;
  const state = {
    posts: [],
    type: "all",
    query: "",
    tokens: ls.get("glimpse:tokens", {}),   // delete tokens for posts made in this browser
    liked: new Set(ls.get("glimpse:liked", [])),
  };
  const postById = id => state.posts.find(p => p.id === id);

  /* ---------------------------------------------------------
     5. CARD MARKUP
     --------------------------------------------------------- */
  function quoteSize(text) {
    const n = text.length;
    return n < 40 ? "xl" : n < 90 ? "l" : n < 170 ? "m" : "s";
  }
  function quoteHTML(p) {
    const style = QUOTE_STYLES.some(s => s.id === p.style) ? p.style : "ink";
    const by = p.quoteBy || p.author;
    return `<div class="quote quote--${style} quote--${quoteSize(p.text || "")}">
      <blockquote>${esc(p.text)}</blockquote>
      ${by ? `<cite>${esc(by)}</cite>` : ""}
    </div>`;
  }
  function cardHTML(p) {
    if (p.type === "quote") return quoteHTML(p);
    const badge = p.type === "video"
      ? `<span class="card__badge"><svg viewBox="0 0 24 24"><path d="M8 5.5v13l10-6.5z"/></svg>${fmtDur(p.duration || 0)}</span>` : "";
    const caption = p.caption
      ? `<span class="card__caption"><strong>${esc(p.caption)}</strong><span>${esc(p.author)}</span></span>`
      : `<span class="card__caption card__caption--slim"><span>${esc(p.author)}</span></span>`;
    return `<img class="card__img" src="${esc(p.thumb)}" alt="" draggable="false" decoding="async">${badge}${caption}`;
  }
  function aspect(p) {
    if (p.type === "quote") return 1.15;
    if (p.width && p.height) return clamp(p.height / p.width, 0.62, 1.6);
    return 1.25;
  }
  function label(p) {
    if (p.type === "quote") return `Quote: ${p.text}${p.quoteBy ? `, ${p.quoteBy}` : ""}`;
    return `${p.type === "video" ? "Video" : "Photo"} by ${p.author}${p.caption ? `: ${p.caption}` : ""}`;
  }

  /* ---------------------------------------------------------
     6. THE WALL + INFINITE ZOOM
     Each card has a spot on a repeating tile and a depth between
     0 (far) and 1 (near). Zooming shifts every depth together and
     wraps it, so cards fly past you and come back far away.
     --------------------------------------------------------- */
  const canvas = $("#canvas");
  const world = $("#world");
  let cards = [];
  let tile = { w: 0, h: 0 };
  let vw = innerWidth, vh = innerHeight;
  let BASE = 200, UNIT = 105;

  const S_MIN = 0.35, S_MAX = 4;
  const LOG_RANGE = Math.log(S_MAX / S_MIN);
  const depthScale = de => S_MIN * Math.exp(de * LOG_RANGE);
  const ZOOM_STEP = 0.12;
  const cam = { x: 0, y: 0, vx: 0, vy: 0, z: 0, tz: 0, ax: 0, ay: 0, focus: null };

  function buildWall(isFirst) {
    vw = innerWidth; vh = innerHeight;
    const small = vw < 700;
    BASE = small ? 150 : 200;
    UNIT = small ? 78 : 105;
    const cell = small ? 160 : 230;
    tile.w = Math.ceil((vw + 300) / 0.42 / cell) * cell;
    tile.h = Math.ceil((vh + 300) / 0.42 / cell) * cell;
    const cols = tile.w / cell, rows = tile.h / cell;

    world.innerHTML = "";
    cards = [];
    $("#empty").hidden = state.posts.length > 0;
    if (!state.posts.length) return;

    const rand = mulberry32(2026);
    let deck = [];
    const draw = () => {
      if (!deck.length) deck = state.posts.slice().sort(() => rand() - 0.5);
      return deck.pop();
    };

    const frag = document.createDocumentFragment();
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const post = draw();
        const card = {
          post, ar: aspect(post), d0: rand(),
          x: c * cell + rand() * cell * 0.7,
          y: r * cell + rand() * cell * 0.7,
          el: document.createElement("button"),
        };
        const el = card.el;
        el.className = `card card--${post.type}` + (isFirst && !reduceMotion ? " intro" : "");
        el.type = "button";
        el.tabIndex = -1;
        el.dataset.id = post.id;
        el.setAttribute("aria-label", label(post));
        el.style.setProperty("--w", BASE + "px");
        el.style.setProperty("--ar", card.ar.toFixed(3));
        el.style.setProperty("--delay", (rand() * 1.1).toFixed(2) + "s");
        el.innerHTML = `<div class="card__inner">${cardHTML(post)}</div>`;
        if (el.classList.contains("intro")) {
          el.addEventListener("animationend", () => el.classList.remove("intro"), { once: true });
        }
        cards.push(card);
        frag.appendChild(el);
      }
    }
    world.appendChild(frag);
    applyFilter();
    render(true);
  }

  function render(force) {
    const cx = vw / 2, cy = vh / 2;
    for (const c of cards) {
      const de = mod(c.d0 + cam.z, 1);
      const s = depthScale(de);
      const u = mod(c.x - cam.x, tile.w) - tile.w / 2;
      const v = mod(c.y - cam.y, tile.h) - tile.h / 2;
      const w = UNIT * s, h = w * c.ar;
      const sx = cx + u * s - w / 2;
      const sy = cy + v * s - h / 2;
      const alpha = (0.3 + 0.7 * smooth(0, 0.7, de)) * smooth(0.02, 0.16, de) * (1 - smooth(0.8, 0.97, de));
      c.de = de; c.s = s; c.w = w; c.h = h; c.sx = sx; c.sy = sy;

      const visible = alpha > 0.01 && sx > -w && sx < vw && sy > -h && sy < vh;
      if (visible !== c.visible || force) {
        c.visible = visible;
        c.el.style.visibility = visible ? "visible" : "hidden";
      }
      if (!visible) continue;
      c.el.style.transform = `translate3d(${sx.toFixed(1)}px, ${sy.toFixed(1)}px, 0) scale(${(w / BASE).toFixed(4)})`;
      c.el.style.opacity = alpha.toFixed(3);
      const zi = Math.round(de * 1000);
      if (zi !== c.zi) { c.zi = zi; c.el.style.zIndex = zi; }
      const tab = de > 0.5 && de < 0.8 ? 0 : -1;
      if (tab !== c.tab) { c.tab = tab; c.el.tabIndex = tab; }
    }
  }

  function applyZoom(dz, ax, ay) {
    if (!dz) return;
    const k = Math.exp(dz * LOG_RANGE);
    cam.x += (ax - vw / 2) * (1 - 1 / k);
    cam.y += (ay - vh / 2) * (1 - 1 / k);
    cam.z += dz;
  }
  function zoomBy(dz, ax = vw / 2, ay = vh / 2) {
    if (ax !== cam.ax || ay !== cam.ay) {
      applyZoom(cam.tz - cam.z, cam.ax, cam.ay);
      cam.ax = ax; cam.ay = ay;
    }
    cam.tz += dz;
  }

  function tick() {
    let moved = false;
    const dzLeft = cam.tz - cam.z;
    if (Math.abs(dzLeft) > 0.0002) {
      applyZoom(reduceMotion ? dzLeft : dzLeft * 0.14, cam.ax, cam.ay);
      moved = true;
    }
    if (cam.focus) {
      const c = cam.focus;
      const ox = c.sx + c.w / 2 - vw / 2, oy = c.sy + c.h / 2 - vh / 2;
      const k = reduceMotion ? 1 : 0.1;
      cam.x += (ox / c.s) * k; cam.y += (oy / c.s) * k;
      if (Math.hypot(ox, oy) < 1 && Math.abs(cam.tz - cam.z) < 0.001) cam.focus = null;
      moved = true;
    } else if (!dragging && (Math.abs(cam.vx) > 0.05 || Math.abs(cam.vy) > 0.05)) {
      cam.x += cam.vx; cam.y += cam.vy;
      cam.vx *= 0.93; cam.vy *= 0.93;
      moved = true;
    }
    if (moved) render();
    requestAnimationFrame(tick);
  }

  // Zoom + pan so the nearest card matching `test` sits mid-screen at a readable size
  function glideTo(test) {
    applyZoom(cam.tz - cam.z, cam.ax, cam.ay);
    render();
    let best = null, bestDist = Infinity;
    for (const c of cards) {
      if (!test(c) || c.de < 0.2 || c.de > 0.8) continue;
      const dist = Math.hypot(c.sx + c.w / 2 - vw / 2, c.sy + c.h / 2 - vh / 2);
      if (dist < bestDist) { bestDist = dist; best = c; }
    }
    if (!best) return;
    cam.vx = cam.vy = 0;
    cam.ax = vw / 2; cam.ay = vh / 2;
    cam.tz = cam.z + (0.66 - best.de);
    cam.focus = best;
  }

  /* ----- Pointer: drag (one pointer), pinch-zoom (two) ----- */
  let dragging = false, pointerDown = false, downCard = null;
  let last = { x: 0, y: 0, t: 0 }, start = { x: 0, y: 0 };
  const pointers = new Map();
  let pinch = null;
  const pinchInfo = () => {
    const [a, b] = [...pointers.values()];
    return { dist: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
  };

  canvas.addEventListener("pointerdown", e => {
    if (e.button !== 0) return;
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    canvas.setPointerCapture?.(e.pointerId);
    cam.focus = null;
    if (pointers.size === 2) {
      pinch = pinchInfo();
      dragging = true; downCard = null;
      canvas.classList.add("dragging");
      cam.vx = cam.vy = 0;
      return;
    }
    pointerDown = true;
    downCard = e.target.closest(".card");
    start = { x: e.clientX, y: e.clientY };
    last = { x: e.clientX, y: e.clientY, t: performance.now() };
    cam.vx = cam.vy = 0;
  });

  window.addEventListener("pointermove", e => {
    if (pointers.has(e.pointerId)) pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && pointers.size >= 2) {
      const now = pinchInfo();
      const dz = Math.log(now.dist / pinch.dist) / LOG_RANGE;
      cam.x -= now.mx - pinch.mx; cam.y -= now.my - pinch.my;
      cam.tz += dz; applyZoom(dz, now.mx, now.my);
      cam.ax = now.mx; cam.ay = now.my;
      pinch = now;
      render();
      return;
    }
    if (!pointerDown) return;
    const dx = e.clientX - last.x, dy = e.clientY - last.y;
    if (!dragging && Math.hypot(e.clientX - start.x, e.clientY - start.y) > 5) {
      dragging = true;
      canvas.classList.add("dragging");
      stopHoverVideo();
    }
    if (dragging) {
      cam.x -= dx; cam.y -= dy;
      const now = performance.now(), dt = Math.max(1, now - last.t);
      cam.vx = (-dx / dt) * 16; cam.vy = (-dy / dt) * 16;
      render();
    }
    last = { x: e.clientX, y: e.clientY, t: performance.now() };
  });

  function endPointer(e) {
    pointers.delete(e.pointerId);
    if (pinch) {
      if (pointers.size < 2) pinch = null;
      if (pointers.size === 1) {
        const p = [...pointers.values()][0];
        last = { x: p.x, y: p.y, t: performance.now() };
        return;
      }
    }
    if (pointers.size > 0) return;
    if (!pointerDown && !dragging) return;
    pointerDown = false;
    if (dragging) {
      dragging = false;
      canvas.classList.remove("dragging");
      if (performance.now() - last.t > 80) cam.vx = cam.vy = 0;
    } else if (downCard && e.type === "pointerup") {
      openViewer(downCard.dataset.id, downCard);
    }
    downCard = null;
  }
  window.addEventListener("pointerup", endPointer);
  window.addEventListener("pointercancel", endPointer);

  world.addEventListener("keydown", e => {
    const card = e.target.closest(".card");
    if (card && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); openViewer(card.dataset.id, card); }
  });

  canvas.addEventListener("wheel", e => {
    e.preventDefault();
    cam.focus = null;
    const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? vh : 1;
    const dx = e.deltaX * unit, dy = e.deltaY * unit;
    if (!e.ctrlKey && Math.abs(dx) > Math.abs(dy)) { cam.x += dx; cam.vx = 0; render(); return; }
    zoomBy(clamp(-dy * (e.ctrlKey ? 0.01 : 0.0012), -0.3, 0.3), e.clientX, e.clientY);
  }, { passive: false });

  const anyModalOpen = () => !$("#viewer").hidden || !$("#composer").hidden;
  window.addEventListener("keydown", e => {
    if (e.target.matches("input, textarea") || anyModalOpen()) return;
    const step = 14;
    if (e.key === "ArrowLeft")  cam.vx -= step;
    if (e.key === "ArrowRight") cam.vx += step;
    if (e.key === "ArrowUp")    cam.vy -= step;
    if (e.key === "ArrowDown")  cam.vy += step;
    if (e.key === "+" || e.key === "=") zoomBy(ZOOM_STEP);
    if (e.key === "-" || e.key === "_") zoomBy(-ZOOM_STEP);
  });
  $("#zoomIn").addEventListener("click", () => zoomBy(ZOOM_STEP * 1.5));
  $("#zoomOut").addEventListener("click", () => zoomBy(-ZOOM_STEP * 1.5));

  let resizeT;
  window.addEventListener("resize", () => { clearTimeout(resizeT); resizeT = setTimeout(() => buildWall(false), 150); });

  /* ----- Videos play (muted) while you hover them ----- */
  let hoverVideo = null;
  function stopHoverVideo() { hoverVideo?.remove(); hoverVideo = null; }
  world.addEventListener("pointerover", e => {
    if (e.pointerType !== "mouse" || dragging) return;
    const el = e.target.closest(".card--video");
    if (!el || el.querySelector("video")) return;
    const p = postById(el.dataset.id);
    if (!p?.url) return;
    stopHoverVideo();
    const v = document.createElement("video");
    Object.assign(v, { src: p.url, muted: true, loop: true, playsInline: true, autoplay: true, className: "card__video" });
    v.setAttribute("aria-hidden", "true");
    el.querySelector(".card__inner").appendChild(v);
    v.play().catch(() => {});
    hoverVideo = v;
  });
  world.addEventListener("pointerout", e => {
    const el = e.target.closest(".card--video");
    if (el && !el.contains(e.relatedTarget)) stopHoverVideo();
  });

  /* ---------------------------------------------------------
     7. SEARCH + FILTERS
     --------------------------------------------------------- */
  const input = $("#searchInput");
  const status = $("#searchStatus");

  function matches(p) {
    if (state.type !== "all" && p.type !== state.type) return false;
    const q = state.query.trim().toLowerCase();
    if (!q) return true;
    const hay = `${p.caption || ""} ${p.text || ""} ${p.quoteBy || ""} ${p.author || ""}`.toLowerCase();
    return q.split(/\s+/).every(w => hay.includes(w));
  }

  function applyFilter() {
    const active = state.type !== "all" || state.query.trim();
    const hits = new Set();
    for (const c of cards) {
      const hit = matches(c.post);
      c.el.classList.toggle("is-dim", !!active && !hit);
      if (hit) hits.add(c.post.id);
    }
    if (!active) { status.innerHTML = ""; return hits; }
    const n = state.posts.filter(matches).length;
    const what = state.type === "all" ? "post" : state.type;
    status.innerHTML = (n
      ? `${n} ${what}${n > 1 ? "s" : ""}${state.query.trim() ? ` match “${esc(state.query.trim())}”` : ""}.`
      : `Nothing matches yet. Try another word or show all posts.`) + `<button type="button" id="clearSearch">Show all</button>`;
    return hits;
  }

  function setFilter({ type = state.type, query = state.query } = {}) {
    state.type = type; state.query = query;
    input.value = query;
    $$(".chip").forEach(ch => ch.setAttribute("aria-pressed", String(ch.dataset.type === type)));
    const hits = applyFilter();
    if ((type !== "all" || query.trim()) && hits.size) glideTo(c => !c.el.classList.contains("is-dim"));
  }

  $("#searchForm").addEventListener("submit", e => { e.preventDefault(); setFilter({ query: input.value }); });
  input.addEventListener("input", () => { if (!input.value) setFilter({ query: "" }); });
  status.addEventListener("click", e => { if (e.target.id === "clearSearch") setFilter({ type: "all", query: "" }); });
  $("#chips").addEventListener("click", e => {
    const b = e.target.closest(".chip");
    if (b) setFilter({ type: b.dataset.type });
  });
  $("#discoverToggle").addEventListener("click", e => {
    const collapsed = $("#discover").classList.toggle("collapsed");
    e.currentTarget.setAttribute("aria-expanded", String(!collapsed));
  });

  /* ---------------------------------------------------------
     8. VIEWER
     --------------------------------------------------------- */
  const viewer = $("#viewer");
  let viewing = null, returnFocus = null;

  function openViewer(id, fromEl) {
    const p = postById(id);
    if (!p) return;
    viewing = p;
    returnFocus = fromEl || document.activeElement;
    stopHoverVideo();

    const media = $("#vMedia");
    media.className = "viewer__media" + (p.type === "quote" ? " viewer__media--quote" : "");
    if (p.type === "photo") {
      media.innerHTML = `<img src="${esc(p.url)}" alt="${esc(p.caption || `Photo by ${p.author}`)}">`;
    } else if (p.type === "video") {
      media.innerHTML = `<video src="${esc(p.url)}" poster="${esc(p.thumb)}" controls autoplay playsinline loop></video>`;
    } else {
      media.innerHTML = `<div class="viewer__quote">${quoteHTML(p)}</div>`;
    }
    $("#vAuthor").textContent = p.author || "Anonymous";
    $("#vTime").textContent = timeAgo(p.createdAt);
    $("#vCaption").textContent = p.type === "quote" ? (p.quoteBy ? `Shared by ${p.author}` : "") : (p.caption || "");
    renderLike();
    $("#vDelete").hidden = !state.tokens[p.id];
    viewer.hidden = false;
    $(".modal__close", viewer).focus();
  }

  function closeViewer() {
    viewer.hidden = true;
    $("#vMedia").innerHTML = "";        // stops video playback
    viewing = null;
    returnFocus?.focus?.({ preventScroll: true });
  }

  function renderLike() {
    const liked = state.liked.has(viewing.id);
    const btn = $("#vLike");
    btn.setAttribute("aria-pressed", String(liked));
    btn.setAttribute("aria-label", liked ? "Unlike" : "Like");
    $("#vLikes").textContent = viewing.likes || 0;
  }

  $("#vLike").addEventListener("click", async () => {
    const p = viewing;
    const delta = state.liked.has(p.id) ? -1 : 1;
    delta > 0 ? state.liked.add(p.id) : state.liked.delete(p.id);
    p.likes = Math.max(0, (p.likes || 0) + delta);      // optimistic update
    ls.set("glimpse:liked", [...state.liked]);
    renderLike();
    if (delta > 0) { const b = $("#vLike"); b.classList.remove("pulse"); void b.offsetWidth; b.classList.add("pulse"); }
    try {
      p.likes = await store.like(p.id, delta);
      if (viewing === p) renderLike();
    } catch (err) { toast(err.message); }
  });

  $("#vDelete").addEventListener("click", async () => {
    const p = viewing;
    if (!confirm("Delete this post from the wall? This can't be undone.")) return;
    try {
      await store.remove(p.id, state.tokens[p.id]);
      delete state.tokens[p.id];
      ls.set("glimpse:tokens", state.tokens);
      state.posts = state.posts.filter(x => x.id !== p.id);
      closeViewer();
      buildWall(false);
      toast("Post deleted");
    } catch (err) { toast(err.message); }
  });

  viewer.addEventListener("click", e => { if (e.target.closest("[data-close]")) closeViewer(); });

  /* ---------------------------------------------------------
     9. COMPOSER
     --------------------------------------------------------- */
  const composer = $("#composer");
  const form = $("#composeForm");
  const fileInput = $("#fileInput");
  const drop = $("#drop");
  const preview = $("#dropPreview");
  const postBtn = $("#postBtn");
  const errorEl = $("#formError");
  const quoteText = $("#quoteText");
  const quoteBy = $("#quoteBy");
  const authorName = $("#authorName");
  let kind = "photo", prepared = null, quoteStyle = "ink", busy = false;

  // Style swatches
  $("#styleRow").innerHTML = QUOTE_STYLES.map((s, i) => `
    <label class="swatch swatch--${s.id}" title="${s.label}">
      <input type="radio" name="qstyle" value="${s.id}" ${i === 0 ? "checked" : ""} aria-label="${s.label}">
      <span aria-hidden="true">Aa</span>
    </label>`).join("");
  $("#styleRow").addEventListener("change", e => { quoteStyle = e.target.value; updateQuotePreview(); });

  function openComposer() {
    authorName.value = ls.get("glimpse:name", "");
    setKind(kind);
    composer.hidden = false;
    $(".seg [aria-selected='true']").focus();
  }
  function closeComposer() {
    if (busy) return;
    composer.hidden = true;
    clearFile();
    form.reset();
    quoteStyle = "ink";
    errorEl.textContent = "";
    updateQuotePreview();
  }

  function setKind(k) {
    kind = k;
    $$(".seg button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.kind === k)));
    $("#mediaPane").hidden = k === "quote";
    $("#quotePane").hidden = k !== "quote";
    if (k !== "quote") {
      fileInput.accept = k === "photo" ? "image/*" : "video/mp4,video/webm,video/quicktime,video/*";
      $("#dropTitle").textContent = k === "photo" ? "Choose a photo" : "Choose a video";
      $("#dropSub").textContent = k === "photo"
        ? "or drop it here. JPG, PNG or WebP."
        : `or drop it here. Up to ${MAX_VIDEO_SECONDS} seconds and ${MAX_VIDEO_MB} MB.`;
      if (prepared && prepared.kind !== k) clearFile();
    }
    errorEl.textContent = "";
    updatePostBtn();
  }
  $(".seg").addEventListener("click", e => { const b = e.target.closest("button[data-kind]"); if (b) setKind(b.dataset.kind); });

  function clearFile() {
    if (prepared?.previewUrl) URL.revokeObjectURL(prepared.previewUrl);
    prepared = null;
    preview.innerHTML = "";
    drop.classList.remove("has-file");
    fileInput.value = "";
    updatePostBtn();
  }

  function updatePostBtn() {
    const ok = kind === "quote" ? quoteText.value.trim().length >= 2 : !!prepared;
    postBtn.disabled = !ok || busy;
  }

  // Wait for one of two events, with a timeout
  function once(el, okEvt, badEvt, ms = 15000) {
    return new Promise((res, rej) => {
      const t = setTimeout(() => { cleanup(); rej(new Error("timeout")); }, ms);
      const ok = () => { cleanup(); res(); };
      const bad = () => { cleanup(); rej(new Error(badEvt)); };
      const cleanup = () => { clearTimeout(t); el.removeEventListener(okEvt, ok); if (badEvt) el.removeEventListener(badEvt, bad); };
      el.addEventListener(okEvt, ok, { once: true });
      if (badEvt) el.addEventListener(badEvt, bad, { once: true });
    });
  }

  function toJpeg(src, maxPx, quality) {
    const sw = src.videoWidth || src.naturalWidth || src.width;
    const sh = src.videoHeight || src.naturalHeight || src.height;
    const k = Math.min(1, maxPx / Math.max(sw, sh));
    const w = Math.round(sw * k), h = Math.round(sh * k);
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    const ctx = cv.getContext("2d");
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, w, h);    // flatten transparent PNGs
    ctx.drawImage(src, 0, 0, w, h);
    return new Promise((res, rej) => cv.toBlob(b => (b ? res({ blob: b, w, h }) : rej(new Error("encode"))), "image/jpeg", quality));
  }

  async function preparePhoto(file) {
    if (!file.type.startsWith("image/")) throw new Error("That file isn't a photo. Choose a JPG, PNG or WebP image.");
    if (file.size > MAX_PHOTO_MB * 1e6) throw new Error(`That photo is ${Math.round(file.size / 1e6)} MB. Choose one under ${MAX_PHOTO_MB} MB.`);
    let src;
    try {
      src = await createImageBitmap(file, { imageOrientation: "from-image" });
    } catch (_) {
      throw new Error("Your browser can't open this photo format. Try a JPG or PNG instead.");
    }
    const full = await toJpeg(src, PHOTO_MAX_PX, 0.86);
    const thumb = await toJpeg(src, THUMB_MAX_PX, 0.8);
    src.close?.();
    return {
      kind: "photo", media: full.blob, mediaName: "photo.jpg", thumb: thumb.blob,
      width: full.w, height: full.h, previewUrl: URL.createObjectURL(thumb.blob),
    };
  }

  async function prepareVideo(file) {
    if (!file.type.startsWith("video/")) throw new Error("That file isn't a video. Choose an MP4, WebM or MOV clip.");
    if (file.size > MAX_VIDEO_MB * 1e6) throw new Error(`That video is ${Math.round(file.size / 1e6)} MB. Videos can be up to ${MAX_VIDEO_MB} MB.`);
    const url = URL.createObjectURL(file);
    const v = document.createElement("video");
    v.muted = true; v.playsInline = true; v.preload = "auto"; v.src = url;
    try {
      await once(v, "loadeddata", "error");
      let d = v.duration;
      if (!isFinite(d)) {                         // some WebM files don't report length up front
        v.currentTime = 1e7;
        await once(v, "seeked");
        d = v.duration;
      }
      if (!(d > 0)) throw new Error("length");
      if (d > MAX_VIDEO_SECONDS + 0.5) {
        throw new Error(`This video is ${Math.round(d)} seconds long. Videos can be ${MAX_VIDEO_SECONDS} seconds at most, so trim it and try again.`);
      }
      v.currentTime = Math.min(1, d / 3);
      await once(v, "seeked");
      const thumb = await toJpeg(v, THUMB_MAX_PX, 0.8);
      return {
        kind: "video", media: file, mediaName: file.name || "video.mp4", thumb: thumb.blob,
        width: v.videoWidth, height: v.videoHeight, duration: Math.round(d * 100) / 100, previewUrl: url,
      };
    } catch (err) {
      URL.revokeObjectURL(url);
      if (err.message.includes("seconds")) throw err;
      throw new Error("Your browser can't read this video. Try an MP4 (H.264) file instead.");
    }
  }

  async function takeFile(file) {
    if (!file) return;
    clearFile();
    errorEl.textContent = "";
    drop.classList.add("busy");
    try {
      const looksVideo = file.type.startsWith("video/");
      if (looksVideo && kind === "photo") setKind("video");
      if (!looksVideo && file.type.startsWith("image/") && kind === "video") setKind("photo");
      prepared = kind === "video" ? await prepareVideo(file) : await preparePhoto(file);
      preview.innerHTML = prepared.kind === "video"
        ? `<video src="${prepared.previewUrl}" muted autoplay loop playsinline></video><span class="meta">${fmtDur(prepared.duration)}</span>`
        : `<img src="${prepared.previewUrl}" alt="Selected photo">`;
      drop.classList.add("has-file");
    } catch (err) {
      errorEl.textContent = err.message;
      fileInput.value = "";
    } finally {
      drop.classList.remove("busy");
      updatePostBtn();
    }
  }

  fileInput.addEventListener("change", () => takeFile(fileInput.files[0]));
  ["dragenter", "dragover"].forEach(t => drop.addEventListener(t, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(t => drop.addEventListener(t, () => drop.classList.remove("over")));
  drop.addEventListener("drop", e => { e.preventDefault(); takeFile(e.dataTransfer.files[0]); });

  function updateQuotePreview() {
    const text = quoteText.value.trim() || "Your words here.";
    $("#quotePreview").innerHTML = quoteHTML({ text, quoteBy: quoteBy.value.trim(), author: authorName.value.trim(), style: quoteStyle });
    $("#quoteCount").textContent = `${quoteText.value.length} / ${QUOTE_MAX}`;
  }
  [quoteText, quoteBy, authorName].forEach(el => el.addEventListener("input", () => { updateQuotePreview(); updatePostBtn(); }));
  updateQuotePreview();

  form.addEventListener("submit", async e => {
    e.preventDefault();
    if (postBtn.disabled) return;
    const author = authorName.value.trim();
    ls.set("glimpse:name", author);
    const data = { type: kind, author: author || "Anonymous" };
    if (kind === "quote") {
      Object.assign(data, { text: quoteText.value.trim().slice(0, QUOTE_MAX), quoteBy: quoteBy.value.trim(), style: quoteStyle });
    } else {
      Object.assign(data, {
        caption: $("#caption").value.trim(),
        media: prepared.media, mediaName: prepared.mediaName, thumb: prepared.thumb,
        width: prepared.width, height: prepared.height, duration: prepared.duration,
      });
    }

    busy = true; updatePostBtn();
    errorEl.textContent = "";
    const bar = $("#uploadBar");
    bar.hidden = kind === "quote";
    bar.style.setProperty("--p", "0%");
    postBtn.textContent = kind === "quote" ? "Posting…" : "Uploading…";

    try {
      const { post, deleteToken } = await store.create(data, p => bar.style.setProperty("--p", Math.round(p * 100) + "%"));
      state.tokens[post.id] = deleteToken;
      ls.set("glimpse:tokens", state.tokens);
      state.posts.unshift(post);
      busy = false;
      closeComposer();
      if (state.type !== "all" && state.type !== post.type) setFilter({ type: "all" });
      buildWall(false);
      glideTo(c => c.post.id === post.id);
      toast("Posted to the wall");
    } catch (err) {
      errorEl.textContent = err.message;
    } finally {
      busy = false;
      bar.hidden = true;
      postBtn.textContent = "Post to the wall";
      updatePostBtn();
    }
  });

  composer.addEventListener("click", e => { if (e.target.closest("[data-close]")) closeComposer(); });
  document.addEventListener("click", e => { if (e.target.closest("[data-open-composer]")) openComposer(); });

  window.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    if (!viewer.hidden) closeViewer();
    else if (!composer.hidden) closeComposer();
  });

  /* ---------------------------------------------------------
     10. THEME, NOTICE, POLLING, BOOT
     --------------------------------------------------------- */
  const themeBtn = $("#themeBtn");
  function setTheme(t) {
    document.documentElement.dataset.theme = t;
    themeBtn.setAttribute("aria-label", t === "dark" ? "Switch to light mode" : "Switch to dark mode");
    ls.set("glimpse:theme", t);
  }
  setTheme(ls.get("glimpse:theme", null) || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
  themeBtn.addEventListener("click", () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark"));

  $("#noticeClose").addEventListener("click", () => { $("#notice").hidden = true; ls.set("glimpse:noticeClosed", true); });

  // Server mode: check for other people's posts and offer to show them
  let pending = null;
  async function poll() {
    try {
      const latest = await store.list();
      const known = new Set(state.posts.map(p => p.id));
      const fresh = latest.filter(p => !known.has(p.id));
      const likes = new Map(latest.map(p => [p.id, p.likes]));
      state.posts.forEach(p => { if (likes.has(p.id)) p.likes = likes.get(p.id); });
      const pill = $("#newPill");
      if (fresh.length) {
        pending = latest;
        pill.textContent = `${fresh.length} new post${fresh.length > 1 ? "s" : ""}. Show them`;
        pill.hidden = false;
      }
    } catch (_) { /* try again next time */ }
  }
  $("#newPill").addEventListener("click", e => {
    if (!pending) return;
    const known = new Set(state.posts.map(p => p.id));
    const newest = pending.find(p => !known.has(p.id));
    state.posts = pending; pending = null;
    e.currentTarget.hidden = true;
    buildWall(false);
    if (newest) glideTo(c => c.post.id === newest.id);
  });

  async function boot() {
    store = await pickStore();
    if (store.mode === "local" && !ls.get("glimpse:noticeClosed", false)) $("#notice").hidden = false;
    try {
      state.posts = await store.list();
    } catch (err) {
      toast(err.message);
      state.posts = [];
    }
    buildWall(true);
    requestAnimationFrame(tick);
    if (store.mode === "server") setInterval(poll, POLL_MS);
  }
  boot();
})();
