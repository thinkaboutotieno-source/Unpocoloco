/* ==========================================================
   Glimpse server
   Serves the front end, stores uploads on disk and keeps posts
   in a JSON file. Good for a small community wall; for heavy
   traffic, swap the JSON file for a database and the uploads
   folder for object storage (S3, R2, Cloudinary...).

   Run:  npm install  &&  npm start   →  http://localhost:3000
   ========================================================== */
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DB_FILE = path.join(DATA_DIR, "posts.json");

const MAX_VIDEO_SECONDS = 30;
const MAX_VIDEO_BYTES = 60 * 1e6;
const MAX_PHOTO_BYTES = 12 * 1e6;     // photos arrive already resized by the browser
const MAX_THUMB_BYTES = 2 * 1e6;
const QUOTE_MAX = 280;
const QUOTE_STYLES = ["ink", "paper", "sun", "bloom"];
const POSTS_PER_10_MIN = 12;          // per IP address

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ----- Tiny JSON "database" ----- */
const SEED = [
  ["We suffer more often in imagination than in reality.", "Seneca", "ink"],
  ["If you want to go fast, go alone. If you want to go far, go together.", "African proverb", "sun"],
  ["Do what you can, with what you have, where you are.", "Theodore Roosevelt", "paper"],
  ["Go confidently in the direction of your dreams.", "Henry David Thoreau", "bloom"],
  ["Nothing great was ever achieved without enthusiasm.", "Ralph Waldo Emerson", "sun"],
  ["Waste no more time arguing what a good person should be. Be one.", "Marcus Aurelius", "ink"],
  ["Little by little, one travels far.", "Proverb", "bloom"],
  ["Until the lion learns to write, tales of the hunt will glorify the hunter.", "African proverb", "paper"],
  ["The best way out is always through.", "Robert Frost", "ink"],
  ["Rest is not idleness.", "John Lubbock", "paper"],
  ["Simplicity is the ultimate sophistication.", "Attributed to Leonardo da Vinci", "sun"],
  ["Wherever you go, go with all your heart.", "Confucius", "bloom"],
];

function load() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch (_) {
    const now = Date.now();
    const posts = SEED.map(([text, quoteBy, style], i) => ({
      id: "sample-" + i, type: "quote", author: "Glimpse", text, quoteBy, style,
      likes: 3 + ((i * 7) % 20), createdAt: now - (i + 1) * 3.6e6,
    }));
    save(posts);
    return posts;
  }
}
function save(list = posts) {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(list, null, 2));
  fs.renameSync(tmp, DB_FILE);               // atomic replace
}
let posts = load();

const publicPost = ({ tokenHash, ip, ...p }) => p;
const sha256 = s => crypto.createHash("sha256").update(s).digest("hex");
const clean = (v, max) => String(v ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
const httpError = (status, message) => Object.assign(new Error(message), { status });

/* ----- Uploads ----- */
const EXT = {
  "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
  "video/mp4": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
};
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, crypto.randomUUID() + (EXT[file.mimetype] || "")),
  }),
  limits: { fileSize: MAX_VIDEO_BYTES, files: 2, fields: 20 },
  fileFilter: (req, file, cb) => {
    const okMedia = file.fieldname === "media" && EXT[file.mimetype];
    const okThumb = file.fieldname === "thumb" && file.mimetype === "image/jpeg";
    cb(okMedia || okThumb ? null : httpError(400, "That file type isn't supported. Use JPG, PNG, WebP, MP4, WebM or MOV."), true);
  },
});

// Reads the real video length with ffprobe when it's installed.
function probeDuration(file) {
  return new Promise(resolve => {
    execFile("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file], { timeout: 15000 }, (err, out) => {
      const d = parseFloat(out);
      resolve(err || !isFinite(d) ? null : d);
    });
  });
}
let hasFfprobe = false;
execFile("ffprobe", ["-version"], err => {
  hasFfprobe = !err;
  if (!hasFfprobe) console.warn("ffprobe not found: video length is checked in the browser only. Install ffmpeg to check it on the server too.");
});

/* ----- Simple per-IP rate limit for new posts ----- */
const hits = new Map();
function rateLimit(req, res, next) {
  const now = Date.now(), win = 10 * 60 * 1000;
  const list = (hits.get(req.ip) || []).filter(t => now - t < win);
  if (list.length >= POSTS_PER_10_MIN) return res.status(429).json({ error: "You're posting very fast. Wait a few minutes and try again." });
  list.push(now); hits.set(req.ip, list);
  next();
}

/* ----- App ----- */
const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(ROOT, "public")));
app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "7d", immutable: true }));

app.get("/api/posts", (req, res) => {
  res.json(posts.map(publicPost));
});

app.post("/api/posts", rateLimit, upload.fields([{ name: "media", maxCount: 1 }, { name: "thumb", maxCount: 1 }]), async (req, res, next) => {
  const media = req.files?.media?.[0];
  const thumb = req.files?.thumb?.[0];
  const cleanup = () => [media, thumb].forEach(f => f && fs.unlink(f.path, () => {}));

  try {
    const b = req.body;
    const type = b.type;
    if (!["photo", "video", "quote"].includes(type)) throw httpError(400, "Choose a photo, video or quote to post.");

    const post = {
      id: crypto.randomUUID(),
      type,
      author: clean(b.author, 40) || "Anonymous",
      likes: 0,
      createdAt: Date.now(),
    };

    if (type === "quote") {
      if (media || thumb) throw httpError(400, "Quotes can't include files.");
      post.text = clean(b.text, QUOTE_MAX);
      if (post.text.length < 2) throw httpError(400, "Write a quote before posting.");
      post.quoteBy = clean(b.quoteBy, 60);
      post.style = QUOTE_STYLES.includes(b.style) ? b.style : "ink";
    } else {
      if (!media || !thumb) throw httpError(400, "The upload was incomplete. Choose the file again.");
      const isVideo = media.mimetype.startsWith("video/");
      if (isVideo !== (type === "video")) throw httpError(400, `That file doesn't look like a ${type}.`);
      if (!isVideo && media.size > MAX_PHOTO_BYTES) throw httpError(413, "That photo is too large.");
      if (thumb.size > MAX_THUMB_BYTES) throw httpError(413, "The preview image is too large.");

      post.caption = clean(b.caption, 140);
      post.width = Math.round(clamp(Number(b.width) || 0, 0, 10000));
      post.height = Math.round(clamp(Number(b.height) || 0, 0, 10000));
      post.url = "/uploads/" + media.filename;
      post.thumb = "/uploads/" + thumb.filename;

      if (isVideo) {
        const probed = hasFfprobe ? await probeDuration(media.path) : null;
        const duration = probed ?? Number(b.duration);
        if (!(duration > 0)) throw httpError(400, "Couldn't read the length of that video. Try an MP4 file.");
        if (duration > MAX_VIDEO_SECONDS + 0.5) {
          throw httpError(400, `This video is ${Math.round(duration)} seconds long. Videos can be ${MAX_VIDEO_SECONDS} seconds at most.`);
        }
        post.duration = Math.round(duration * 100) / 100;
      }
    }

    const token = crypto.randomBytes(18).toString("hex");
    post.tokenHash = sha256(token);
    posts.unshift(post);
    save();
    res.status(201).json({ post: publicPost(post), deleteToken: token });
  } catch (err) {
    cleanup();
    next(err);
  }
});

app.post("/api/posts/:id/like", (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "That post no longer exists." });
  const delta = req.body?.delta === -1 ? -1 : 1;
  p.likes = Math.max(0, (p.likes || 0) + delta);
  save();
  res.json({ likes: p.likes });
});

app.delete("/api/posts/:id", (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "That post no longer exists." });
  const token = req.get("X-Delete-Token") || "";
  const adminOk = process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
  if (!adminOk && (!p.tokenHash || sha256(token) !== p.tokenHash)) {
    return res.status(403).json({ error: "Only the person who posted this can delete it." });
  }
  posts = posts.filter(x => x !== p);
  save();
  for (const u of [p.url, p.thumb]) if (u) fs.unlink(path.join(UPLOAD_DIR, path.basename(u)), () => {});
  res.status(204).end();
});

// Errors (including multer's file-size errors) come back as friendly JSON
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === "LIMIT_FILE_SIZE"
      ? `That file is too large. Videos can be up to ${MAX_VIDEO_BYTES / 1e6} MB.`
      : "The upload couldn't be read. Try again.";
    return res.status(413).json({ error: msg });
  }
  if (err.status) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server. Try again." });
});

function clamp(n, a, b) { return Math.min(b, Math.max(a, n)); }

app.listen(PORT, () => console.log(`Glimpse is running at http://localhost:${PORT}`));
