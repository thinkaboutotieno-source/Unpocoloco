# Glimpse

An infinite, zoomable wall where people post photos, videos of up to 30 seconds, and quotes.

## Run it

You need Node.js 18 or newer.

```bash
npm install
npm start
```

Open http://localhost:3000. Everyone who opens that address sees the same wall.

Install **ffmpeg** too if you can (`brew install ffmpeg`, `sudo apt install ffmpeg`, or from ffmpeg.org).
The browser already refuses videos over 30 seconds, but with ffmpeg the server checks the real length
of every upload as well, so nobody can get around the limit.

## Project layout

```
server.js          Express server: API, uploads, JSON storage
public/index.html  Page structure
public/style.css   Styles
public/script.js   Wall, zoom, uploads, viewer
data/posts.json    Created on first run; all posts live here
uploads/           Created on first run; uploaded files live here
```

## How uploads work

- **Photos** are resized in the browser to 1800px on the long edge before upload, plus a 520px thumbnail for the wall.
- **Videos** are checked in the browser for length (30 s) and size (60 MB). A thumbnail is captured from the first second.
  The server checks type, size and length again.
- **Quotes** are up to 280 characters with four card styles.

Each new post returns a private delete token that is saved in the poster's browser, so only they can delete it.
To delete anything as the site owner, start the server with `ADMIN_TOKEN=some-long-secret npm start` and send that
value in the `X-Delete-Token` header:

```bash
curl -X DELETE -H "X-Delete-Token: some-long-secret" http://localhost:3000/api/posts/POST_ID
```

## Settings worth knowing

| Setting | Where | Default |
| --- | --- | --- |
| Max video length | `MAX_VIDEO_SECONDS` in `server.js` and `public/script.js` | 30 |
| Max video size | `MAX_VIDEO_BYTES` (server), `MAX_VIDEO_MB` (browser) | 60 MB |
| Posts per IP per 10 minutes | `POSTS_PER_10_MIN` in `server.js` | 12 |
| Check for new posts | `POLL_MS` in `public/script.js` | 20 s |

## Before going public

This is a solid starting point for a small community, but a public site needs a few more things:

- **Moderation.** Anyone can post anything. Add a review queue, a report button, or an image and video moderation service.
- **Storage.** Move uploads to object storage (S3, Cloudflare R2, Cloudinary) and posts to a real database
  (SQLite, Postgres) once traffic grows. The JSON file is rewritten on every change.
- **Accounts** if you want people to manage their posts across devices.
- **HTTPS**, which most hosts (Render, Railway, Fly.io) provide automatically.
